import { Request, Response } from 'express';

export interface Drama {
  id: number;
  title: string;
  episodes: number;
  description: string;
  quote: string;
}

let dramas: Drama[] = [
  {
    id: 1,
    title: "Daily Dose of Sunshine",
    episodes: 12,
    description: "Mengisahkan Jung Da-eun, seorang perawat berhati hangat yang baru dipindahkan ke departemen kesehatan jiwa (psikiatri) dan berjuang memberikan secercah harapan bagi para pasiennya.",
    quote: "Malam paling gelap selalu datang tepat sebelum fajar menyingsing."
  },
  {
    id: 2,
    title: "Resident Playbook",
    episodes: 12,
    description: "Spin-off dari Hospital Playlist yang menyoroti kehidupan nyata, perjuangan berat, dan persahabatan para dokter residen obstetri dan ginekologi (OBGYN) di Yulje Medical Center cabang Jongno.",
    quote: "Setiap kelahiran adalah keajaiban, begitu pula proses kita bertumbuh menjadi dokter sejati."
  },
  {
    id: 3,
    title: "Hospital Playlist",
    episodes: 24,
    description: "Kisah lima dokter spesialis yang telah bersahabat sejak masuk sekolah kedokteran pada tahun 1999. Mereka bekerja di rumah sakit yang sama dan menyalurkan hobi bermusik lewat sebuah band.",
    quote: "Orang jahat tidak akan pernah berpikir bahwa dirinya jahat. Hanya orang baik yang khawatir apakah mereka sudah cukup baik."
  },
  {
    id: 4,
    title: "Our Unwritten Seoul",
    episodes: 12,
    description: "Kisah dua saudari kembar identik dengan kepribadian dan kehidupan yang sangat bertolak belakang. Karena suatu keadaan, mereka bertukar identitas dan mulai menemukan arti hidup serta penyembuhan diri di kota Seoul.",
    quote: "Halaman yang belum tertulis di kota ini adalah milik kita untuk dilukis bersama."
  }
];

export const getAllDramas = (req: Request, res: Response): void => {
  res.json(dramas);
};

export const createDrama = (req: Request, res: Response): void => {
  const { title, episodes, description, quote } = req.body;
  const newId = dramas.length > 0 ? Math.max(...dramas.map(d => d.id)) + 1 : 1;

  const newDrama: Drama = {
    id: newId,
    title,
    episodes: Number(episodes),
    description,
    quote
  };

  dramas.push(newDrama);
  res.status(201).json(newDrama);
};

export const updateDrama = (req: Request, res: Response): void => {
  const id = parseInt(req.params.id);
  const { title, episodes, description, quote } = req.body;
  const index = dramas.findIndex(d => d.id === id);

  if (index !== -1) {
    dramas[index] = {
      id,
      title,
      episodes: Number(episodes),
      description,
      quote
    };
    res.json(dramas[index]);
  } else {
    res.status(404).json({ message: 'Data drama tidak ditemukan' });
  }
};

export const deleteDrama = (req: Request, res: Response): void => {
  const id = parseInt(req.params.id);
  const index = dramas.findIndex(d => d.id === id);

  if (index !== -1) {
    const deleted = dramas.splice(index, 1);
    res.json(deleted[0]);
  } else {
    res.status(404).json({ message: 'Data drama tidak ditemukan' });
  }
};
